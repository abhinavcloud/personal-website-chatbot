import os
import json
import re
from hashlib import sha256
import boto3
from botocore.exceptions import ClientError
from botocore.exceptions import BotoCoreError
from botocore.config import Config

ses = boto3.client(
    "sesv2",
    config=Config(
        connect_timeout=3,
        read_timeout=8,
        retries={"total_max_attempts": 1},
    ),
)

mail_table = boto3.resource(
    "dynamodb",
    config=Config(
        connect_timeout=2,
        read_timeout=3,
        retries={"total_max_attempts": 1},
    ),
).Table(os.environ["MAIL_TABLE_NAME"])

SENDER = os.environ["ASSISTANT_EMAIL"]
RECIPIENT = os.environ["RECEIPIENT_EMAIL"]


def lambda_handler(event, context):
    if not isinstance(event, dict):
        return {"status": "error", "message": "Invalid request."}

    subject = event.get("subject")
    body = event.get("body")

    if not isinstance(subject, str) or not subject.strip():
        return {"status": "error", "message": "Subject is required."}

    if not isinstance(body, str) or not body.strip():
        return {"status": "error", "message": "Message body is required."}

    subject = subject.strip()
    body = body.strip()

    # Application limits, not SES service limits.
    if len(subject) > 200 or "\r" in subject or "\n" in subject:
        return {"status": "error", "message": "Invalid subject."}

    if len(body) > 10000:
        return {"status": "error", "message": "Message body is too long."}


    reply_to = event.get("reply_to")

    if not isinstance(reply_to, str):
        return {
            "status": "error",
            "message": "An authenticated reply-to email is required.",
        }

    reply_to = reply_to.strip()

    if (
        len(reply_to) > 254
        or reply_to.count("@") != 1
        or any(character.isspace() for character in reply_to)
        or not all(reply_to.split("@"))
    ):
        return {
            "status": "error",
            "message": "Invalid reply-to email address.",
        }

    request_id = event.get("request_id")

    if not isinstance(request_id, str) or not re.fullmatch(
        r"[A-Za-z0-9_#-]{1,200}", request_id
    ):
        return {"status": "error", "message": "Invalid request ID."}

    key = f"send#{request_id}"

    fingerprint = sha256(json.dumps(
        [SENDER, RECIPIENT, reply_to, subject, body],
        ensure_ascii=False,
        separators=(",", ":"),
    ).encode()).hexdigest()

    unknown = {
        "status": "unknown",
        "message": (
            "Email submission could not be confirmed. "
            "Do not automatically resend."
        ),
    }

    try:
        mail_table.put_item(
            Item={
                "id": key,
                "fingerprint": fingerprint,
                "result": unknown,
            },
            ConditionExpression="attribute_not_exists(id)",
        )
    except ClientError as exc:
        if exc.response["Error"]["Code"] != "ConditionalCheckFailedException":
            raise

        existing = mail_table.get_item(
            Key={"id": key},
            ConsistentRead=True,
        ).get("Item")

        if existing is None:
            return unknown

        if existing["fingerprint"] != fingerprint:
            return {
                "status": "error",
                "message": "Request ID already used for different email content.",
            }

        return existing["result"]

    try:
        response = ses.send_email(
            FromEmailAddress=SENDER,
            Destination={
                "ToAddresses": [RECIPIENT],
            },
            ReplyToAddresses=[reply_to],
            Content={
                "Simple": {
                    "Subject": {    
                        "Data": subject,
                        "Charset": "UTF-8",
                    },
                    "Body": {
                        "Text": {
                            "Data": body,
                            "Charset": "UTF-8",
                        },
                    },
                }
            },
        )
    except ClientError as exc:
        http_status = exc.response.get(
            "ResponseMetadata", {}
        ).get("HTTPStatusCode", 0)

        code = exc.response["Error"]["Code"]

        if (
            400 <= http_status < 500
            and code not in ("RequestTimeout", "RequestTimeoutException")
        ):
            result = {
                "status": "error",
                "message": "SES rejected the email request.",
            }
        else:
            result = unknown

        print({
            "event": "ses_send_failed",
            "error_code": code,
            "request_id": context.aws_request_id,
            "error_message": exc.response["Error"].get("Message", ""),
        })

    except BotoCoreError:
        result = unknown

    else:
        result = {
            "status": "submitted",
            "message": "Email submitted to Abhinav.",
            "message_id": response["MessageId"],
        }

    mail_table.update_item(
        Key={"id": key},
        UpdateExpression="SET #result = :result",
        ConditionExpression="fingerprint = :fingerprint",
        ExpressionAttributeNames={"#result": "result"},
        ExpressionAttributeValues={
            ":result": result,
            ":fingerprint": fingerprint,
        },
    )

    return result