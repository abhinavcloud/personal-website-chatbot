import os
import re
import json
import base64
import urllib.request
import urllib.error
import urllib.parse

import yaml

# ---------------------------------------------------------------------------
# Config (set these as Lambda environment variables)
# ---------------------------------------------------------------------------
GITHUB_OWNER = os.environ["GITHUB_OWNER"]
GITHUB_REPO = os.environ["GITHUB_REPO"]
GITHUB_BRANCH = os.environ["GITHUB_BRANCH"]
RESUME_PATH = os.environ["RESUME_PATH"]
GITHUB_API = os.environ.get("GITHUB_API", "https://api.github.com")
JSDELIVR_BASE = f"https://cdn.jsdelivr.net/gh/{GITHUB_OWNER}/{GITHUB_REPO}@{GITHUB_BRANCH}"

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?\n)---\s*\n", re.DOTALL)


# ---------------------------------------------------------------------------
# GitHub / jsDelivr fetch helpers
# ---------------------------------------------------------------------------
def _github_headers() -> dict:
    return {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "abhinav-personal-website-lambda",
    }


def github_get(path: str):
    url = (
        f"{GITHUB_API}/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/"
        f"{path.lstrip('/')}?ref={urllib.parse.quote(GITHUB_BRANCH)}"
    )
    req = urllib.request.Request(url, headers=_github_headers())
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        if e.code == 403 and "rate limit" in body.lower():
            remaining = e.headers.get("x-ratelimit-remaining", "unknown")
            reset = e.headers.get("x-ratelimit-reset", "unknown")
            raise RuntimeError(
                "GITHUB_RATE_LIMIT_EXCEEDED: The website data source (GitHub API) has "
                f"hit its request rate limit (remaining={remaining}, reset_epoch={reset}). "
                "This is a temporary infrastructure issue, not missing data. Do not guess, "
                "infer, or fabricate an answer. Tell the user plainly that live data is "
                "temporarily unavailable due to rate limiting and to try again shortly."
            )
        raise


def jsdelivr_get_raw_content(path: str) -> str:
    url = f"{JSDELIVR_BASE}/{path.lstrip('/')}"
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=15) as resp:
        return resp.read().decode("utf-8")


def github_get_raw_content(path: str) -> str:
    try:
        return jsdelivr_get_raw_content(path)
    except Exception:
        data = github_get(path)
        if data.get("type") != "file":
            raise ValueError(f"{path} is not a file.")
        encoded = data.get("content")
        if not encoded:
            raise ValueError(f"No content returned for {path}")
        return base64.b64decode(encoded.replace("\n", "")).decode("utf-8")


# ---------------------------------------------------------------------------
# Frontmatter parsing
# ---------------------------------------------------------------------------
def parse_frontmatter(content: str) -> dict:
    match = FRONTMATTER_RE.match(content)
    if not match:
        return {}
    try:
        metadata = yaml.safe_load(match.group(1))
        return metadata if isinstance(metadata, dict) else {}
    except yaml.YAMLError:
        return {}


def strip_frontmatter(content: str) -> str:
    return FRONTMATTER_RE.sub("", content, count=1).lstrip("\n")


def _first_present(metadata: dict, *keys, default=""):
    """
    Return the value of the first key present (and non-empty/non-None) in
    metadata. Frontmatter field names drift between "email"/"emails",
    "phone"/"telephone"/"mobile", etc. Silently returning "" on a name
    mismatch produces empty/undisclosed contact fields even when the resume
    actually has the data under a slightly different key. This does not
    fabricate anything - it only widens the set of accepted spellings for
    the SAME field.
    """
    for key in keys:
        if key in metadata and metadata[key] not in (None, "", []):
            return metadata[key]
    return default


# ---------------------------------------------------------------------------
# Tool implementation
# ---------------------------------------------------------------------------
def read_resume():
    content = github_get_raw_content(RESUME_PATH)
    metadata = parse_frontmatter(content)
    body = strip_frontmatter(content)

    return {
        "path": RESUME_PATH,
        "contact": {
            "name": _first_present(metadata, "name", "full_name"),
            "title": _first_present(metadata, "title", "role", "headline"),
            "location": _first_present(metadata, "location", "city"),
            "phone": _first_present(metadata, "phone", "telephone", "mobile", "phone_number"),
            "email": _first_present(metadata, "email", "emails", "email_address", default=[]),
            "linkedin": _first_present(metadata, "linkedin", "linkedIn", "linkedin_url"),
            "github": _first_present(metadata, "github", "github_url"),
            "website": _first_present(metadata, "website", "site", "url"),
        },
        "content": body,
    }


TOOL_DISPATCH = {
    "read_resume": lambda event: read_resume(),
}


# ---------------------------------------------------------------------------
# Lambda entry point
# ---------------------------------------------------------------------------
def _extract_tool_name(event, context) -> str:
    """
    AgentCore Gateway tells you which tool was invoked via the context object
    (bedrockAgentCoreToolName), possibly prefixed with the target name
    (e.g. "myTarget___read_resume"). We check a couple of likely spots
    defensively and log everything on the first calls so you can confirm the
    exact shape against your gateway and simplify this later.
    """
    tool_name = ""
    client_context = getattr(context, "client_context", None)
    if client_context is not None:
        custom = getattr(client_context, "custom", None) or {}
        tool_name = custom.get("bedrockAgentCoreToolName", "")

    if not tool_name and isinstance(event, dict):
        tool_name = event.get("bedrockAgentCoreToolName", "")

    if "___" in tool_name:
        tool_name = tool_name.split("___")[-1]

    return tool_name


def lambda_handler(event, context):
    print("EVENT:", json.dumps(event, default=str))
    print("CLIENT_CONTEXT_CUSTOM:", getattr(getattr(context, "client_context", None), "custom", None))

    tool_name = _extract_tool_name(event, context)
    handler = TOOL_DISPATCH.get(tool_name)
    if handler is None:
        raise ValueError(f"Unknown or missing tool name: '{tool_name}'")

    return handler(event)
