import os
import re
import json
import time
import base64
import urllib.request
import urllib.error
import urllib.parse

import yaml

# ---------------------------------------------------------------------------
# Config (set these as Lambda environment variables)
# ---------------------------------------------------------------------------
GITHUB_OWNER = os.environ["GITHUB_OWNER"]
GITHUB_REPO = os.environ["GITHUB_REPO"]
GITHUB_BRANCH = os.environ["GITHUB_BRANCH"]
PROJECTS_PATH = os.environ["PROJECTS_PATH"]
GITHUB_API = os.environ.get("GITHUB_API", "https://api.github.com")
JSDELIVR_BASE = f"https://cdn.jsdelivr.net/gh/{GITHUB_OWNER}/{GITHUB_REPO}@{GITHUB_BRANCH}"

FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?\n)---\s*\n", re.DOTALL)

# Best-effort, per-warm-execution-environment cache only. Not shared across
# concurrent invocations. Fine as an optimization, not correctness-critical.
CACHE_TTL_SECONDS = 300
_entry_cache: dict = {}


# ---------------------------------------------------------------------------
# GitHub / jsDelivr fetch helpers
# ---------------------------------------------------------------------------
def _github_headers() -> dict:
    return {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "abhinav-personal-website-lambda",
    }


def github_get(path: str):
    url = (
        f"{GITHUB_API}/repos/{GITHUB_OWNER}/{GITHUB_REPO}/contents/"
        f"{path.lstrip('/')}?ref={urllib.parse.quote(GITHUB_BRANCH)}"
    )
    req = urllib.request.Request(url, headers=_github_headers())
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="ignore")
        if e.code == 403 and "rate limit" in body.lower():
            remaining = e.headers.get("x-ratelimit-remaining", "unknown")
            reset = e.headers.get("x-ratelimit-reset", "unknown")
            raise RuntimeError(
                "GITHUB_RATE_LIMIT_EXCEEDED: The website data source (GitHub API) has "
                f"hit its request rate limit (remaining={remaining}, reset_epoch={reset}). "
                "This is a temporary infrastructure issue, not missing data. Do not guess, "
                "infer, or fabricate an answer. Tell the user plainly that live data is "
                "temporarily unavailable due to rate limiting and to try again shortly."
            )
        raise


def jsdelivr_get_raw_content(path: str) -> str:
    url = f"{JSDELIVR_BASE}/{path.lstrip('/')}"
    req = urllib.request.Request(url)
    with urllib.request.urlopen(req, timeout=15) as resp:
        return resp.read().decode("utf-8")


def github_get_raw_content(path: str) -> str:
    try:
        return jsdelivr_get_raw_content(path)
    except Exception:
        data = github_get(path)
        if data.get("type") != "file":
            raise ValueError(f"{path} is not a file.")
        encoded = data.get("content")
        if not encoded:
            raise ValueError(f"No content returned for {path}")
        return base64.b64decode(encoded.replace("\n", "")).decode("utf-8")


# ---------------------------------------------------------------------------
# Frontmatter parsing
# ---------------------------------------------------------------------------
def parse_frontmatter(content: str) -> dict:
    match = FRONTMATTER_RE.match(content)
    if not match:
        return {}
    try:
        metadata = yaml.safe_load(match.group(1))
        return metadata if isinstance(metadata, dict) else {}
    except yaml.YAMLError:
        return {}


def strip_frontmatter(content: str) -> str:
    return FRONTMATTER_RE.sub("", content, count=1).lstrip("\n")


# ---------------------------------------------------------------------------
# Entry listing / reading
# ---------------------------------------------------------------------------
def list_markdown_entries(dir_path: str, force_refresh: bool = False) -> list:
    now = time.time()
    if not force_refresh:
        cached = _entry_cache.get(dir_path)
        if cached and (now - cached[0]) < CACHE_TTL_SECONDS:
            return cached[1]

    data = github_get(dir_path)
    if not isinstance(data, list):
        raise ValueError(f"{dir_path} is not a directory")

    entries = []
    for item in data:
        if item.get("type") != "file":
            continue
        name = item.get("name", "")
        path = item.get("path", "")
        if not name.lower().endswith((".md", ".mdx")):
            continue

        content = github_get_raw_content(path)
        metadata = parse_frontmatter(content)

        entries.append({
            "name": name,
            "path": path,
            "title": metadata.get("title", name),
            "subtitle": metadata.get("subtitle", ""),
            "date": str(metadata.get("date", "")),
            "readingTime": metadata.get("readingTime", ""),
            "tags": metadata.get("tags", []),
            "icon": metadata.get("icon", ""),
            "has_full_content": True,
        })

    sorted_entries = sorted(entries, key=lambda x: x.get("date") or "", reverse=True)
    _entry_cache[dir_path] = (now, sorted_entries)
    return sorted_entries


def read_markdown_entry(path: str, root: str, kind: str) -> dict:
    normalized = path.strip("/")
    root_normalized = root.strip("/")
    if not normalized.startswith(root_normalized + "/"):
        raise ValueError(f"Access denied: path is outside the {kind} directory.")
    if not normalized.lower().endswith((".md", ".mdx")):
        raise ValueError("Only Markdown/MDX files are allowed.")

    content = github_get_raw_content(normalized)
    metadata = parse_frontmatter(content)
    body = strip_frontmatter(content)

    return {
        "path": normalized,
        "title": metadata.get("title", ""),
        "subtitle": metadata.get("subtitle", ""),
        "date": str(metadata.get("date", "")),
        "readingTime": metadata.get("readingTime", ""),
        "tags": metadata.get("tags", []),
        "icon": metadata.get("icon", ""),
        "content": body,
    }


def _pick_extreme(entries: list, newest: bool) -> dict:
    if not entries:
        return {}
    dated = [e for e in entries if e.get("date")]
    pool = dated or entries
    return max(pool, key=lambda x: x.get("date") or "") if newest else min(pool, key=lambda x: x.get("date") or "")


def _top_n(entries: list, n: int, newest: bool) -> list:
    dated = [e for e in entries if e.get("date")]
    pool = dated or entries
    ordered = sorted(pool, key=lambda x: x.get("date") or "", reverse=newest)
    return ordered[: max(0, n)]


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------
def list_projects():
    return list_markdown_entries(PROJECTS_PATH)


def get_first_project():
    return _pick_extreme(list_markdown_entries(PROJECTS_PATH), newest=False)


def get_last_project():
    return _pick_extreme(list_markdown_entries(PROJECTS_PATH), newest=True)


def get_latest_projects(n: int = 4):
    return _top_n(list_markdown_entries(PROJECTS_PATH), n, newest=True)


def get_oldest_projects(n: int = 4):
    return _top_n(list_markdown_entries(PROJECTS_PATH), n, newest=False)


def read_projects(path: str):
    return read_markdown_entry(path, PROJECTS_PATH, "project")


TOOL_DISPATCH = {
    "list_projects": lambda event: list_projects(),
    "get_first_project": lambda event: get_first_project(),
    "get_last_project": lambda event: get_last_project(),
    "get_latest_projects": lambda event: get_latest_projects(event.get("n", 4)),
    "get_oldest_projects": lambda event: get_oldest_projects(event.get("n", 4)),
    "read_projects": lambda event: read_projects(event["path"]),
}


# ---------------------------------------------------------------------------
# Lambda entry point
# ---------------------------------------------------------------------------
def _extract_tool_name(event, context) -> str:
    """
    AgentCore Gateway tells you which tool was invoked via the context object
    (bedrockAgentCoreToolName), possibly prefixed with the target name
    (e.g. "myTarget___read_projects"). We check a couple of likely spots
    defensively and log everything on the first calls so you can confirm the
    exact shape against your gateway and simplify this later.
    """
    tool_name = ""
    client_context = getattr(context, "client_context", None)
    if client_context is not None:
        custom = getattr(client_context, "custom", None) or {}
        tool_name = custom.get("bedrockAgentCoreToolName", "")

    if not tool_name and isinstance(event, dict):
        tool_name = event.get("bedrockAgentCoreToolName", "")

    if "___" in tool_name:
        tool_name = tool_name.split("___")[-1]

    return tool_name


def lambda_handler(event, context):
    print("EVENT:", json.dumps(event, default=str))
    print("CLIENT_CONTEXT_CUSTOM:", getattr(getattr(context, "client_context", None), "custom", None))

    tool_name = _extract_tool_name(event, context)
    handler = TOOL_DISPATCH.get(tool_name)
    if handler is None:
        raise ValueError(f"Unknown or missing tool name: '{tool_name}'")

    return handler(event)
